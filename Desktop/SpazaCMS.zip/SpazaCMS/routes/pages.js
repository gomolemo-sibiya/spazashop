//Include express
var express = require('express');
var router = express.Router();
//Get page model
var Page = require('../models/page');

//Use a get request - the slash means home or index
router.get('/', function(req, res) {
    Page.findOne({slug: 'home'}, function (err, page) {
        if(err)
            console.log(err);

            res.render('index', {
                title: page.title, 
                content: page.content
        });
    });
});

//Use a get request - the slash means home or index
router.get('/', function(req, res) {
   
    var slug = req.params.slug;

    Page.findOne({slug: slug}, function (err, page) {
        if(err)
            console.log(err);

        if(!page){
            res.redirect('/');
        } else {
            res.render('index', {
                title: page.title, 
                content: page.content
            });
        }
    });
});

//Exports
module.exports = router;