//3
//Include express
var express = require('express');
var router = express.Router();
//var passport = require('passport');
var bcrypt = require('bcryptjs');

//Get Users model
var User = require('../models/user');

const { render } = require('ejs');
const passport = require('../config/passport');


/**
 * Now copy and paste the route from app.js
 * Then get rid of route from database.js
 * Then set routes in database.js
 */
//To test the server
//Use a get register - the slash means home or index
router.get('/register', function(req, res) {
    res.render('register', {
        title: 'Register',

    });
});

//Use a POST register - the slash means home or index
router.post('/register', function(req, res) {
    var name = req.body.name;
    var email = req.body.email;
    var username = req.body.username;
    var password = req.body.password;
    var password2 = req.body.password2; 

    //Validation
    req.checkBody('name', 'Name is required').notEmpty();
    req.checkBody('email', 'Email is required').isEmail();
    req.checkBody('username', 'Username is required').notEmpty();
    req.checkBody('password', 'Password is required').notEmpty();
    req.checkBody('password2', 'Password do not match').equals(password);

    var errors = req.validationErrors();

    if(errors){
        res.render('register', {
            errors: errors,
            user: null,
            title: 'Register'
        });
    } else {
        //Make sure username is unique
        User.findOne({username: username}, function (err, user) {
            if (err) 
                console.log(err);

            if(user){
                req.flash('danger', 'Username exists, choose another!');
                res.redirect('/users/register');
            } else {
                //If there is no user, i will add a new user
                var user = new User({
                    name: name,
                    email: email,
                    username: username,
                    password: password,
                    admin: 1
                });

                // Hash the password
                bcrypt.genSalt(10, function (err, salt) {
                    bcrypt.hash(user.password, salt, function (err, hash) {
                        if(err) console.log(err);
                        
                        user.password = hash;
                        
                        user.save(function (err) {
                            if(err) {
                                console.log(err);
                            }
                            else {
                                req.flash('success', 'You are now registered');
                                res.redirect('/users/login')
                            }
                        });
                    });
                });
            }
        });
    }
});

//Use a get login - the slash means home or index
router.get('/login', function(req, res) {
    if(res.locals.user) res.redirect('/');

    res.render('login', {
        title: 'Log in'
    });
});

//Use a Post login - the slash means home or index
router.get('/login', function(req, res, next) {
    
    passport.authenticate('local', {
        successRedirect: '/',
        failureRedirect: '/users/login',
        failureFlash: true,
    })(req, res, next);
});

//Use a get logout - the slash means home or index
router.get('/logout', function(req, res) {
    req.logout();
    req.flash('flash', 'You are logged out');
    res.redirect('/users/login');
});

//Exports
module.exports = router;